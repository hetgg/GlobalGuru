<?php

	include_once("adminheader.php");

?>

<?php 
	if(isset($_POST['submit'])){
		$optselect=$_POST['optselect'];
        $z=trim($optselect);
        
		$cnn=mysqli_connect("localhost","root","","dbglobalguru");
		$qry="Select *  from user where city='$z' ";
		$result=$cnn->query($qry);
		echo $qry;

		$str="<table class='table  table-bordered table-hover'><tr><th>teacherid</th><th>username</th><th>Gender</th>><th>contactno</th><th>email</th></tr>";

			while($row=$result->fetch_assoc())
			{
				$str.="<tr><td>".$row["uid"]."</td><td>".$row["uname"]."</td><td>".$row["Gender"]."</td><td>".$row["contactno"]."</td><td>".$row["email"]."</td><td>".$row["doj"]."</td></tr>";
			}

		$str.="</table>";

		echo $str;

	}
?>
<script src="cities.js"></script>
<br>
<br>
<form class="form-horizontal" role="form" method="post">
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Select City </label>

										<div class="col-sm-9">
											
											<select onchange="print_city('state', this.selectedIndex);" id="sts" name ="tstate" class="form-control" required style="width:200px;"></select>
											<select id ="state" name="optselect" class="form-control" style="width:200px;" required></select>
											<script language="javascript">print_state("sts");</script>
										</div>
									</div>
					

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info" name="submit" value="Submit">
												
											&nbsp; &nbsp; &nbsp;
											<input type="reset" class="btn" type="reset" name="Reset">
												

										</div>
									</div>
								</form>

<?php

	include_once("adminfooter.php");

?>
