<?php 
include_once("adminheader.php");
?>

<?php 
	$cnn=mysqli_connect("localhost","root","","dbglobalguru");

	$flag=5; //just for declaration
	//flag for validation
	//flag=0  success
	//flag=1  wrong current pass
	//flag=2  password and newpassword cannot be blank
	//flag=3  current password cannot be blank
	//flag=4  newpassword and confirm password must be same

	if(isset($_POST['submit'])){
        $cnn=mysqli_connect("localhost","root","","dbglobalguru");
        $adminid=17;
		$cpass=$_POST['cpass'];
		$npass=$_POST['npass'];
		$conpass=$_POST['conpass'];

		if($cpass=="" && $npass==""){
			$flag=2;
		}

		else if($cpass==""){
			$flag=3;
		}

		elseif ($npass!=$conpass) {
			$flag=4;
		}
		
            $qry="Select * from admin where aid='$adminid' AND apassword='$cpass'";

            
            $result=$cnn->query($qry);
            $row=$result->fetch_assoc();
            $x=mysqli_num_rows($result);
            echo "<h1>Count = $x</h1>";
            
                if($x==1){
                    $qry="UPDATE admin SET apassword= '$npass' WHERE apassword= '$cpass'";
		            $result=$cnn->query($qry);
		            $flag=0;
                }
 
                else{
                    $flag=1;
                 }
	}
?>		

<h3 class="header smaller lighter blue">Update details</h3>
								<form class="form-horizontal" role="form" method="post">
									
									<div class="form-group">

										<label class="col-sm-3 control-label no-padding-right" for="form-field-1" > Current Password: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Current Password" name="cpass"  class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> New Password: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="New Password" name="npass"  class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Confirm Password: </label>	
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Confirm Password" name="conpass"  class="col-xs-10 col-sm-5" />
										</div>
										
									</div>
					                  <?php

					               		if($flag==0){					                  		
												echo "<font style='color:green;font-size:15px;text-align:center;'>Password Successfully Changed</font>";
										}


					                  	if($flag==1){					                  		
												echo "<font style='color:red;font-size:15px;text-align:center;'>Current password is wrong</font>";
										}

										else if($flag==2){
												echo "<font style='color:red;font-size:15px;text-align:center;'>Password and newpassword cannot be blank</font>";
										}

					                  	if($flag==3){					                  		
												echo "<font style='color:red;font-size:15px;text-align:center;'>Currentpassword cannot be blank</font>";
										}

										else if($flag==4){
												echo "<font style='color:red;font-size:15px;text-align:center;'>newpassword and confirm password must be same</font>";
										}



					                   ?> 
                                    
									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info" name="submit" value="Submit">
												
											&nbsp; &nbsp; &nbsp;
											<input type="reset" class="btn" type="reset" name="Reset">
												

										</div>
									</div>
								</form>


<?php 
include_once("adminfooter.php");
?>
	