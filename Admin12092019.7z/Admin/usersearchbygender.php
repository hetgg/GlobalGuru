<?php

	include_once("adminheader.php");

?>

<?php 
	if(isset($_POST['submit'])){
		$optselect=$_POST['form-field-radio'];
		$cnn=mysqli_connect("localhost","root","","dbglobalguru");
		$qry="Select *  from user where gender='$optselect' ";

		$result=$cnn->query($qry);

		$str="<table class='table  table-bordered table-hover'><tr><th>userid</th><th>username</th><th>Gender</th><th>contactno</th><th>email</th><th>city</th></tr>";

			while($row=$result->fetch_assoc())
			{
				$str.="<tr><td>".$row["uid"]."</td><td>".$row["uname"]."</td><td>".$row["contactno"]."</td><td>".$row["email"]."</td><td>".$row["doj"]."</td><td>".$row["city"]."</td></tr>";
			}

		$str.="</table>";

		echo $str;

	}
?>
<script src="cities.js"></script>
<br>
<br>
<form class="form-horizontal" role="form" method="post">
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right control-label bolder blue" for="form-field-1">Select Gender </label>
										<div class="col-xs-12 col-sm-6">
											<div class="control-group">
												<div class="radio">
													<label>
														<input name="form-field-radio" type="radio" class="ace" value="male" />
														<span class="lbl"> Male</span>
													</label>
												</div>

												<div class="radio">
													<label>
														<input name="form-field-radio" type="radio" class="ace" value="female" />
														<span class="lbl">Female</span>
													</label>
												</div>
											</div>
										</div>
									</div>
					

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info" name="submit" value="Submit">
												
											&nbsp; &nbsp; &nbsp;
											<input type="reset" class="btn" type="reset" name="Reset">
												

										</div>
									</div>
								</form>

<?php

	include_once("adminfooter.php");

?>
