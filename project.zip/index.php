<?php
include_once("header.php");
?>

<div class="page-header">
							<h1>
								Subcategory
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Static &amp; Dynamic Tables
								</small>
							</h1>
						</div><!-- /.page-header -->
<?php 
		$cnn=mysqli_connect("localhost","root","","dbglobalguru");
		$qry="Select * from subcategory";

		$result=$cnn->query($qry);

		$str="<table class='table  table-bordered table-hover'>";

		while($row=$result->fetch_assoc())
		{
				$str.="<tr><td>".$row["subcatid"]."</td><td>".$row["subcatname"]."</td><td>".$row["catid"]."</td><td>".$row["subcateimg"]."</td></tr>";
			}

		$str.="</table>";

		echo $str;



?>


<?php
include_once("footer.php");
?>