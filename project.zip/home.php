<?php
include_once("header.php");
?>

<h1>hi</h1>


<?php
include_once("footer.php");
?>