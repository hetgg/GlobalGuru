<?php 
include_once("adminheader.php");
?>

<?php 
	$cnn=mysqli_connect("localhost","root","","dbglobalguru");
	$adminid=17;

	$qry1="Select * from admin where aid=$adminid";
	$result=$cnn->query($qry1);
	$row=$result->fetch_assoc();
	$adminemail=$row['aemail'];
	$adminphone=$row['aphone'];
    $adminaddress=$row['aaddress'];
	$adminpincode=$row['apincode'];


	


	if(isset($_POST['submit'])){
		
		$adminemail=$_POST['ademail'];
		$adminphone=$_POST['adphone'];
		$adminaddress=$_POST['adaddress'];
        $adminpincode=$_POST['adpincode'];
        

		
		$qry="UPDATE admin SET aemail= '$adminemail',aphone= '$adminphone',aaddress= '$adminaddress',apincode= '$adminpincode' WHERE aid= '$adminid'";
		echo $qry;
		$result=$cnn->query($qry);
	}
?>						

<h3 class="header smaller lighter blue">Update details</h3>
								<form class="form-horizontal" role="form" method="post">
									
									<div class="form-group">

										<label class="col-sm-3 control-label no-padding-right" for="form-field-1" > Email: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="admin email" name="ademail" value="<?php echo $adminemail;?>" class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone No: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="admin phone" name="adphone" value="<?php echo $adminphone;?>" class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Pincode: </label>	
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Admin pincode" name="adpincode" value="<?php echo $adminpincode;?>" class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Admin Address" name="adaddress" value="<?php echo $adminaddress;?>" class="col-xs-10 col-sm-5" />
										</div>
									</div>
					                   
                                    <center> <img src="img//<?php echo $subcateimg; ?>" width="100px" height="100px"></center>
									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info" name="submit" value="Submit">
												
											&nbsp; &nbsp; &nbsp;
											<input type="reset" class="btn" type="reset" name="Reset">
												

										</div>
									</div>
								</form>


<?php 
include_once("adminfooter.php");
?>
	