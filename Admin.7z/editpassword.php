<?php 
include_once("adminheader.php");
?>

<?php 
	$cnn=mysqli_connect("localhost","root","","dbglobalguru");

	if(isset($_POST['submit'])){
        $cnn=mysqli_connect("localhost","root","","dbglobalguru");
        $adminid=17;
		$cpass=$_POST['cpass'];
		$npass=$_POST['npass'];

		
            $qry="Select * from admin where aid='$adminid' AND apassword='$cpass'";

            echo $qry;
            
            $result=$cnn->query($qry);
            $row=$result->fetch_assoc();
            $x=mysqli_num_rows($result);
            echo "<h1>Count = $x</h1>";
            
                if($x==1){
                    $qry="UPDATE admin SET apassword= '$npass' WHERE apassword= '$cpass'";
		            echo $qry;
		            $result=$cnn->query($qry);
                }
 
                else{
                    echo "Wrong Password";
                    }
	}
?>						

<h3 class="header smaller lighter blue">Update details</h3>
								<form class="form-horizontal" role="form" method="post">
									
									<div class="form-group">

										<label class="col-sm-3 control-label no-padding-right" for="form-field-1" > Current Password: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Current Password" name="cpass"  class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> New Password: </label>

										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="New Password" name="npass"  class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Confirm Password: </label>	
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Confirm Password" name="adpincode"  class="col-xs-10 col-sm-5" />
										</div>
										
									</div>
					                   
                                    
									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info" name="submit" value="Submit">
												
											&nbsp; &nbsp; &nbsp;
											<input type="reset" class="btn" type="reset" name="Reset">
												

										</div>
									</div>
								</form>


<?php 
include_once("adminfooter.php");
?>
	